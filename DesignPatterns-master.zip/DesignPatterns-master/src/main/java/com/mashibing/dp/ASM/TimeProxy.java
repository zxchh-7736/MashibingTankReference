package com.mashibing.dp.ASM;

public class TimeProxy {

    public static void before() {
        System.out.println("before ...");
    }
}
