package com.mashibing.dp.bridge.v3;

public class WarmGift extends Gift {
}
