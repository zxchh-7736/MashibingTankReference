package com.mashibing.dp.abstractfactory;

public abstract class Food {
   abstract void printName();
}
