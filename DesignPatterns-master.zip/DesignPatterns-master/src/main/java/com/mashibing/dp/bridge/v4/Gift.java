package com.mashibing.dp.bridge.v4;

public abstract class Gift {
    GiftImpl impl;
}
