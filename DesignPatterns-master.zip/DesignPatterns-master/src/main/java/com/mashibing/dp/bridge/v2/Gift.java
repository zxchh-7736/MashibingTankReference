package com.mashibing.dp.bridge.v2;

public abstract class Gift {}
