package com.mashibing.dp.Iterator.v3;

public interface Collection_ {
    void add(Object o);
    int size();
}
