package com.mashibing.dp.state.thread;

public class Action {
    String msg;
}
