package com.mashibing.dp.bridge.v3;

public class WildGift extends Gift {
}
