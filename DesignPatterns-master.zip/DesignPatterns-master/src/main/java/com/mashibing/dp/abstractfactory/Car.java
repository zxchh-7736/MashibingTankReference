package com.mashibing.dp.abstractfactory;

public class Car extends Vehicle{

    public void go() {
        System.out.println("Car go wuwuwuwuw....");
    }
}
