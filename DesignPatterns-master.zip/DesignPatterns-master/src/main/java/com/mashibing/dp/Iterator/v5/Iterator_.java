package com.mashibing.dp.Iterator.v5;

public interface Iterator_ {
    boolean hasNext();

    Object next();
}
