package com.mashibing.dp.abstractfactory;

public class Broom extends Vehicle{
    public void go() {
        System.out.println("Car go wuwuwuwuw....");
    }
}
