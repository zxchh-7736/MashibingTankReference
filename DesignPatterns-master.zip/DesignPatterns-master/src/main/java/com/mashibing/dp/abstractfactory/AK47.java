package com.mashibing.dp.abstractfactory;

public class AK47 extends Weapon{
    public void shoot() {
        System.out.println("tututututu....");
    }
}
