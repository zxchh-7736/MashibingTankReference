package com.mashibing.dp.bridge.v2;

public class WarmGift extends Gift {
}
