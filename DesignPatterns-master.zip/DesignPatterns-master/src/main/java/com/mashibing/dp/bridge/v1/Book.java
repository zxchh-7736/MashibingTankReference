package com.mashibing.dp.bridge.v1;

public class Book extends Gift {
}
