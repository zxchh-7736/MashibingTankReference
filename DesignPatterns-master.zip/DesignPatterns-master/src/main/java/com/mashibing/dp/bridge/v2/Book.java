package com.mashibing.dp.bridge.v2;

public class Book extends Gift {
}
