package com.mashibing.dp.state.v2;

public class MMSadState extends MMState {
    @Override
    void smile() {

    }

    @Override
    void cry() {

    }

    @Override
    void say() {

    }
}
