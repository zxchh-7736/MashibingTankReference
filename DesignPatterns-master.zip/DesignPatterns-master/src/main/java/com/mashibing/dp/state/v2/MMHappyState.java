package com.mashibing.dp.state.v2;

public class MMHappyState extends MMState {
    @Override
    void smile() {
        System.out.println("happy smile");
    }

    @Override
    void cry() {

    }

    @Override
    void say() {

    }
}
